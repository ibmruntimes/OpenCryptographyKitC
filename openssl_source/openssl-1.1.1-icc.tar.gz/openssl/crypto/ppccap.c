/*
 * Copyright 2009-2019 The OpenSSL Project Authors. All Rights Reserved.
 *
 * Licensed under the OpenSSL license (the "License").  You may not use
 * this file except in compliance with the License.  You can obtain a copy
 * in the file LICENSE in the source distribution or at
 * https://www.openssl.org/source/license.html
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <signal.h>
#include <unistd.h>
#if defined(__linux) || defined(_AIX)
#include <sys/utsname.h>
#endif
#if defined(_AIX53) /* defined even on post-5.3 */
#include <sys/systemcfg.h>
#if !defined(__power_set)
#define __power_set(a) (_system_configuration.implementation & (a))
#endif
#endif

#include <openssl/crypto.h>
#include <openssl/bn.h>
#include <internal/cryptlib.h>
#include <crypto/chacha.h>
#include "bn/bn_local.h"

#include "ppc_arch.h"

unsigned int OPENSSL_ppccap_P = 0;

static sigset_t all_masked;

#ifdef OPENSSL_BN_ASM_MONT
int bn_mul_mont(BN_ULONG *rp, const BN_ULONG *ap, const BN_ULONG *bp,
                const BN_ULONG *np, const BN_ULONG *n0, int num)
{
    int bn_mul_mont_int(BN_ULONG * rp, const BN_ULONG *ap, const BN_ULONG *bp,
                        const BN_ULONG *np, const BN_ULONG *n0, int num);
    int bn_mul4x_mont_int(BN_ULONG * rp, const BN_ULONG *ap, const BN_ULONG *bp,
                          const BN_ULONG *np, const BN_ULONG *n0, int num);

    if (num < 4)
        return 0;

    if ((num & 3) == 0)
        return bn_mul4x_mont_int(rp, ap, bp, np, n0, num);

    /*
     * There used to be [optional] call to bn_mul_mont_fpu64 here,
     * but above subroutine is faster on contemporary processors.
     * Formulation means that there might be old processors where
     * FPU code path would be faster, POWER6 perhaps, but there was
     * no opportunity to figure it out...
     */

    return bn_mul_mont_int(rp, ap, bp, np, n0, num);
}
#endif

void sha256_block_p8(void *ctx, const void *inp, size_t len);
void sha256_block_ppc(void *ctx, const void *inp, size_t len);
void sha256_block_data_order(void *ctx, const void *inp, size_t len);
void sha256_block_data_order(void *ctx, const void *inp, size_t len)
{
    OPENSSL_ppccap_P &PPC_CRYPTO207 ? sha256_block_p8(ctx, inp, len) : sha256_block_ppc(ctx, inp, len);
}

void sha512_block_p8(void *ctx, const void *inp, size_t len);
void sha512_block_ppc(void *ctx, const void *inp, size_t len);
void sha512_block_data_order(void *ctx, const void *inp, size_t len);
void sha512_block_data_order(void *ctx, const void *inp, size_t len)
{
    OPENSSL_ppccap_P &PPC_CRYPTO207 ? sha512_block_p8(ctx, inp, len) : sha512_block_ppc(ctx, inp, len);
}

#ifndef OPENSSL_NO_CHACHA
void ChaCha20_ctr32_int(unsigned char *out, const unsigned char *inp,
                        size_t len, const unsigned int key[8],
                        const unsigned int counter[4]);
void ChaCha20_ctr32_vmx(unsigned char *out, const unsigned char *inp,
                        size_t len, const unsigned int key[8],
                        const unsigned int counter[4]);
void ChaCha20_ctr32_vsx(unsigned char *out, const unsigned char *inp,
                        size_t len, const unsigned int key[8],
                        const unsigned int counter[4]);
void ChaCha20_ctr32(unsigned char *out, const unsigned char *inp,
                    size_t len, const unsigned int key[8],
                    const unsigned int counter[4])
{
    OPENSSL_ppccap_P &PPC_CRYPTO207
        ? ChaCha20_ctr32_vsx(out, inp, len, key, counter)
        : OPENSSL_ppccap_P &PPC_ALTIVEC
              ? ChaCha20_ctr32_vmx(out, inp, len, key, counter)
              : ChaCha20_ctr32_int(out, inp, len, key, counter);
}
#endif

#ifndef OPENSSL_NO_POLY1305
void poly1305_init_int(void *ctx, const unsigned char key[16]);
void poly1305_blocks(void *ctx, const unsigned char *inp, size_t len,
                     unsigned int padbit);
void poly1305_emit(void *ctx, unsigned char mac[16],
                   const unsigned int nonce[4]);
void poly1305_init_fpu(void *ctx, const unsigned char key[16]);
void poly1305_blocks_fpu(void *ctx, const unsigned char *inp, size_t len,
                         unsigned int padbit);
void poly1305_emit_fpu(void *ctx, unsigned char mac[16],
                       const unsigned int nonce[4]);
int poly1305_init(void *ctx, const unsigned char key[16], void *func[2]);
int poly1305_init(void *ctx, const unsigned char key[16], void *func[2])
{
    if (sizeof(size_t) == 4 && (OPENSSL_ppccap_P & PPC_FPU))
    {
        poly1305_init_fpu(ctx, key);
        func[0] = (void *)(uintptr_t)poly1305_blocks_fpu;
        func[1] = (void *)(uintptr_t)poly1305_emit_fpu;
    }
    else
    {
        poly1305_init_int(ctx, key);
        func[0] = (void *)(uintptr_t)poly1305_blocks;
        func[1] = (void *)(uintptr_t)poly1305_emit;
    }
    return 1;
}
#endif

#ifdef ECP_NISTZ256_ASM
void ecp_nistz256_mul_mont(unsigned long res[4], const unsigned long a[4],
                           const unsigned long b[4]);

void ecp_nistz256_to_mont(unsigned long res[4], const unsigned long in[4]);
void ecp_nistz256_to_mont(unsigned long res[4], const unsigned long in[4])
{
    static const unsigned long RR[] = {0x0000000000000003U,
                                       0xfffffffbffffffffU,
                                       0xfffffffffffffffeU,
                                       0x00000004fffffffdU};

    ecp_nistz256_mul_mont(res, in, RR);
}

void ecp_nistz256_from_mont(unsigned long res[4], const unsigned long in[4]);
void ecp_nistz256_from_mont(unsigned long res[4], const unsigned long in[4])
{
    static const unsigned long one[] = {1, 0, 0, 0};

    ecp_nistz256_mul_mont(res, in, one);
}
#endif

static sigjmp_buf ill_jmp;
static void ill_handler(int sig)
{
    siglongjmp(ill_jmp, sig);
}

void OPENSSL_fpu_probe(void);
void OPENSSL_ppc64_probe(void);
void OPENSSL_altivec_probe(void);
void OPENSSL_crypto207_probe(void);
void OPENSSL_madd300_probe(void);

long OPENSSL_rdtsc_mftb(void);
long OPENSSL_rdtsc_mfspr268(void);

unsigned long OPENSSL_rdtsc(void)
{
    if (OPENSSL_ppccap_P & PPC_MFTB)
        return OPENSSL_rdtsc_mftb();
    else if (OPENSSL_ppccap_P & PPC_MFSPR268)
        return OPENSSL_rdtsc_mfspr268();
    else
        return 0;
}

size_t OPENSSL_instrument_bus_mftb(unsigned int *, size_t);
size_t OPENSSL_instrument_bus_mfspr268(unsigned int *, size_t);

size_t OPENSSL_instrument_bus(unsigned int *out, size_t cnt)
{
    if (OPENSSL_ppccap_P & PPC_MFTB)
        return OPENSSL_instrument_bus_mftb(out, cnt);
    else if (OPENSSL_ppccap_P & PPC_MFSPR268)
        return OPENSSL_instrument_bus_mfspr268(out, cnt);
    else
        return 0;
}

size_t OPENSSL_instrument_bus2_mftb(unsigned int *, size_t, size_t);
size_t OPENSSL_instrument_bus2_mfspr268(unsigned int *, size_t, size_t);

size_t OPENSSL_instrument_bus2(unsigned int *out, size_t cnt, size_t max)
{
    if (OPENSSL_ppccap_P & PPC_MFTB)
        return OPENSSL_instrument_bus2_mftb(out, cnt, max);
    else if (OPENSSL_ppccap_P & PPC_MFSPR268)
        return OPENSSL_instrument_bus2_mfspr268(out, cnt, max);
    else
        return 0;
}

/* I wish <sys/auxv.h> was universally available */
#define HWCAP 16 /* AT_HWCAP */
#define HWCAP_PPC64 (1U << 30)
#define HWCAP_ALTIVEC (1U << 28)
#define HWCAP_FPU (1U << 27)
#define HWCAP_POWER6_EXT (1U << 9)
#define HWCAP_VSX (1U << 7)

#define HWCAP2 26 /* AT_HWCAP2 */
#define HWCAP_VEC_CRYPTO (1U << 25)
#define HWCAP_ARCH_3_00 (1U << 23)

#if defined(__GNUC__) && __GNUC__ >= 2
__attribute__((constructor))
#endif

/* Fake auxv for AIX */
#if defined(_AIX)

/* IN theory it works, in practice the data structure changed
   between the AIX 5,.3 we build on and the head AIX's we support
   getsystemcfg() would fix that, but not available on AIX 5.3
   We can't dlopen() and probe, in the middle of a library load
*/
#include "sys/systemcfg.h"

#if !defined(__power_set)
#define __power_set(a) (_system_configuration.implementation & (a))
#endif

#ifndef POWER_6
#define POWER_6 0x4000 /* 6 class CPU */
#endif
#ifndef POWER_7
#define POWER_7 0x8000 /* 7 class CPU */
#endif
#ifndef POWER_8
#define POWER_8 0x10000 /* 8 class CPU */
#endif
#ifndef POWER_9
#define POWER_9 0x20000 /* 9 class CPU */
#endif
#ifndef POWER_10
#define POWER_10 0x40000 /* 10 class CPU */
#endif
/* Just guesses from here on, not even IBM knows */ 
#ifndef POWER_11
#define POWER_11 0x80000 /* 11 class CPU */
#endif
#ifndef POWER_12
#define POWER_12 0x100000 /* 12 class CPU */
#endif

/* This is a fake to make this look like the Linux auxv
   It's even less fine grained.
 */
unsigned long
query_auxv(unsigned int type)
{
    unsigned long cap = 0;
    if (__power_set(POWER_6))
    {
        cap |= POWER_6;
    }
    if (__power_set(POWER_7))
    {
        cap |= POWER_7;
    }
    if (__power_set(POWER_8))
    {
        cap |= POWER_8;
    }
    if (__power_set(POWER_9))
    {
        cap |= POWER_9;
    }
    if (__power_set(POWER_10))
    {
        cap |= POWER_10;
    }
    if (__power_set(POWER_11))
    {
        cap |= POWER_11;
    }
    if (__power_set(POWER_12))
    {
        cap |= POWER_12;
    }
    return cap;
}

#endif

/* Note this code is here so because Power has no usespace CPUID
   a) We can disable stuff that has problems with ICC_CAP_MASK
   b) We can make solid guess at what capabilites can't be present based on model
      and avoid some risky SIGILL's in the probe code 
*/

void OPENSSL_cpuid_setup_real(unsigned long mask)
{
    char *e;
    struct sigaction ill_oact, ill_act;
    sigset_t oset;
    static int trigger = 0;

    if (trigger)
        return;
    trigger = 1;

    if ((e = getenv("OPENSSL_ppccap")))
    {
        OPENSSL_ppccap_P = strtoul(e, NULL, 0);
        return;
    }

    OPENSSL_ppccap_P = 0;

#if defined(_AIX)
    if (sizeof(size_t) == 4)
    {
        struct utsname uts;
#if defined(_SC_AIX_KERNEL_BITMODE)
        if (sysconf(_SC_AIX_KERNEL_BITMODE) != 64)
            return;
#endif
        if (uname(&uts) != 0 || atoi(uts.version) < 6)
            return;
    }
#endif

    sigfillset(&all_masked);
    sigdelset(&all_masked, SIGILL);
    sigdelset(&all_masked, SIGTRAP);
#ifdef SIGEMT
    sigdelset(&all_masked, SIGEMT);
#endif
    sigdelset(&all_masked, SIGFPE);
    sigdelset(&all_masked, SIGBUS);
    sigdelset(&all_masked, SIGSEGV);

    memset(&ill_act, 0, sizeof(ill_act));
    ill_act.sa_handler = ill_handler;
    ill_act.sa_mask = all_masked;

    sigprocmask(SIG_SETMASK, &ill_act.sa_mask, &oset);
    sigaction(SIGILL, &ill_act, &ill_oact);

    if (mask & PPC_FPU)
    {
        if (sigsetjmp(ill_jmp, 1) == 0)
        {
            OPENSSL_fpu_probe();
            OPENSSL_ppccap_P |= PPC_FPU;

            if (sizeof(size_t) == 4)
            {
#ifdef __linux
                struct utsname uts;
                if (uname(&uts) == 0 && strcmp(uts.machine, "ppc64") == 0)
#endif
                    if (sigsetjmp(ill_jmp, 1) == 0)
                    {
                        OPENSSL_ppc64_probe();
                        OPENSSL_ppccap_P |= PPC_FPU64;
                    }
            }
            else
            {
                /*
             * Wanted code detecting POWER6 CPU and setting PPC_FPU64
             */
            }
        }
    }
    if (mask & PPC_ALTIVEC)
    {
        if (sigsetjmp(ill_jmp, 1) == 0)
        {
            OPENSSL_altivec_probe();
            OPENSSL_ppccap_P |= PPC_ALTIVEC;
        }
    }
    if (mask & PPC_CRYPTO207)
    {
        if (sigsetjmp(ill_jmp, 1) == 0)
        {
            OPENSSL_crypto207_probe();
            OPENSSL_ppccap_P |= PPC_CRYPTO207;
        }
    }

    if (mask & PPC_MADD300)
    {
        if (sigsetjmp(ill_jmp, 1) == 0)
        {
            OPENSSL_madd300_probe();
            OPENSSL_ppccap_P |= PPC_MADD300;
        }
    }

    if (mask & PPC_MFTB)
    {
        if (sigsetjmp(ill_jmp, 1) == 0)
        {
            OPENSSL_rdtsc_mftb();
            OPENSSL_ppccap_P |= PPC_MFTB;
        }
    }
    if (mask & PPC_MFSPR268)
    {
            if (sigsetjmp(ill_jmp, 1) == 0)
            {
                OPENSSL_rdtsc_mfspr268();
                OPENSSL_ppccap_P |= PPC_MFSPR268;
            }
    }
    
    sigaction(SIGILL, &ill_oact, NULL);
    sigprocmask(SIG_SETMASK, &oset, NULL);
}

/* Bits you can turn OFF */
#define PPC_ALLOWED_MASK_BITS (PPC_CRYPTO207 | PPC_ALTIVEC | PPC_FPU | PPC_FPU64 | PPC_MADD300 | PPC_MFTB | PPC_MFSPR268)
/* Bits you can turn ON */
#define PPC_PERMITTED_MASK_BITS 0

/* This is the default path, but with ICC we allow 
   override via ICC_CAP_MASK
   What gets set in the mask for ICC is the features we'll
   enable NOT the features available.
   Using the FPU is a win on P6, but halves RSA perf on P7/P8
   so it's not enabled by default on variants with the 2.06 ISA
   flagged.
   Also note what we do here is decide what features we WON'T bother to probe
   for because they won't be present.
*/

void OPENSSL_cpuid_setup()
{
    unsigned long mask = PPC_PERMITTED_MASK_BITS;
    static int trigger = 0;
    unsigned long hwcap = 0;

    /* IBM Specific hack, if ICC_CAP_MASK is set, 
     don't probe function that could cause a SIGILL, 
     as we'll be setting this via OPENSSL_cpuid_override() 
     later. The OpenSSL case would use OPENSSL_ppccap
     but OpenSSL has no override call.
  */

    if (!trigger)
    {
        trigger = 1;

        /* To avoid the SIGILL traps in most cases, 
       only probe for feature which SHOULD be there 
    */
#if defined(__linux)
        /* Assume everything except FPU, let the Gods sort it out */
        mask = PPC_ALLOWED_MASK_BITS;
#elif defined(_AIX)
        /* Alas, we can't make it work across
       the range of OS's we support
    */
        mask = PPC_FPU | PPC_FPU64;
        hwcap = (unsigned long)query_auxv(0);
        if (hwcap &  (POWER_6 | POWER_7 | POWER_8 | POWER_9 | POWER_10| POWER_11 | POWER_12))
        {
            mask |= PPC_ALTIVEC;
        }
        /*
        P5,P7 and above using the FPU paths 
        cuts RSA perf in half
        */
        if (hwcap & (POWER_5 | POWER_7 | POWER_8 | POWER_9 | POWER_10| POWER_11 | POWER_12))
        {
            mask &= (~PPC_FPU64);
        }
        if (hwcap & (POWER_8 | POWER_9 | POWER_10| POWER_11 | POWER_12))
        {
            mask = PPC_CRYPTO207 ;
        }
        if(hwcap & POWER_9) {
            mask |= PPC_MADD300;
        }
        if (hwcap & (POWER_7 | POWER_8 | POWER_9 | POWER_10| POWER_11 | POWER_12))
        {
            mask |= PPC_MFTB;
        }
        if (hwcap & (POWER_6 | POWER_7 | POWER_8 | POWER_9 | POWER_10| POWER_11 | POWER_12))
        {
            mask |= PPC_MFSPR268;
        }
#endif
        /* fprintf(stderr,"ICC MASK %08x %08x\n",mask,hwcap); */
        /*    printf("mask = %08x\n",mask); */
        OPENSSL_cpuid_setup_real(mask);
        /*    printf("cpuid %08lx %08lx\n",OPENSSL_ppccap_P[0],OPENSSL_ppccap_P[1]); */
    }
}

int OPENSSL_cpuid_override(unsigned long long mask)
{
    union {
        unsigned long long cap;
        unsigned int icap[sizeof(unsigned long long) / sizeof(unsigned int)];
    } u;
    int l = sizeof(unsigned long long) / sizeof(unsigned int);
    unsigned long long tmask;
    u.cap = 0;

#if (__BYTE_ORDER == __LITTLE_ENDIAN)
    u.icap[0] = OPENSSL_ppccap_P;
#else
    u.icap[l - 1] = OPENSSL_ppccap_P;
#endif

    tmask = mask & (~PPC_ALLOWED_MASK_BITS);

    u.cap &= tmask;

#if (__BYTE_ORDER == __LITTLE_ENDIAN)
    OPENSSL_ppccap_P = u.icap[0];
#else
    OPENSSL_ppccap_P = u.icap[l - 1];
#endif
    /* fprintf(stderr,"Cpuid override cap %0llx mask %0llx, tmask %0llx ppccap_P %0x\n",u.cap,mask,tmask,OPENSSL_ppccap_P);*/
    return 1;
}

int OPENSSL_cpuid(unsigned long long *id)
{
    union {
        unsigned long long cap;
        unsigned int icap[sizeof(unsigned long long) / sizeof(unsigned int)];
    } u;
    int l = sizeof(unsigned long long) / sizeof(unsigned int);
    u.cap = 0;
    OPENSSL_cpuid_setup();

#if (__BYTE_ORDER == __LITTLE_ENDIAN)
    u.icap[0] = OPENSSL_ppccap_P;
#else
    u.icap[l - 1] = OPENSSL_ppccap_P;
#endif

    /* fprintf(stderr,"cpuid %0x %0x %0x %0llx\n",OPENSSL_ppccap_P,u.icap[0],u.icap[l-1],u.cap);*/
    *id = u.cap;
    return 1;
}
